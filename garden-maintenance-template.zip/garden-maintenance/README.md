# GreenScape — Garden Maintenance Website Template

Готовый HTML-шаблон сайта для компании по уходу за садом и ландшафтом.

## Страницы

- `index.html` — Главная
- `services.html` — Услуги
- `portfolio.html` — Портфолио работ
- `pricing.html` — Цены и тарифы
- `about.html` — О компании
- `contact.html` — Контакты + форма заявки

## Технологии

- HTML5
- CSS3 (кастомные стили)
- Bootstrap 5.3
- Bootstrap Icons
- Vanilla JavaScript

## Как использовать

1. Распакуйте архив
2. Откройте `index.html` в браузере
3. Замените тексты, телефоны, email и изображения на свои
4. Изображения сейчас подгружаются с Unsplash — замените на свои локальные файлы в папке `images/`

## Кастомизация

Основные цвета находятся в `css/style.css` в блоке `:root`:

```css
--primary: #2d6a4f;
--primary-dark: #1b4332;
--primary-light: #40916c;
```

## Готово к продаже

Шаблон полностью адаптивный, чистый код, подходит для выгрузки на WebbyTemplate, ThemeForest, Gumroad и другие маркетплейсы.

© 2026 — создано для продажи на маркетплейсах шаблонов
